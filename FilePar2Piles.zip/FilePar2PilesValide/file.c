#include <stdio.h>
#include <stdlib.h>
#include <assert.h> // Ajout de l'en-t�te assert.h pour pouvoir utiliser la fonction assert
#include "file.h"
#include "pile.h"
// D�claration des fonctions pour la file
