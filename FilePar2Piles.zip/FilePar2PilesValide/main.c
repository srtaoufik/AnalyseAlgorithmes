#include <stdio.h>
#include <stdlib.h>
#include "file.h"

int main() {
    // D�claration d'une structure de file
    struct file f1;
    int elem;
   char choix;
    // Initialisation de la file
    creeFile(&f1);

do{
    printf("Tapez E pour Enfiler, D pour Defiler et une autre touche si vous voulez terminer \n");
    scanf(" %c", &choix);
    if ((choix=='E')||(choix=='e')){
         printf("donnez l'element a enfiler \n");
         scanf("%d", &elem);
         enfiler(elem, &f1);
    }
    else if ((choix=='D')||(choix=='d')){
        printf("defilement de %d \n ", premier(&f1));
        defiler(&f1);
    }
}while((choix=='E')||(choix=='e')||(choix=='D')||(choix=='d'));
    return 0;
}
