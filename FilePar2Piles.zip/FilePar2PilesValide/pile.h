
/******* Partie interface : pile.h *******/
/*repr�sentation physique*/
// D�claration de la structure d'�l�ment de pile
struct element {
    int cle;
    struct element *suivant;
};
/*op�rations  ou services export�*/
struct element* creerpile (void) ;
unsigned vide (struct element*) ;
int dernier (struct element*) ;
void empiler (int,struct element**) ;
void depiler (struct element**) ;

