
// D�claration de la structure de file
struct file {
    struct element * P_In;
    struct element * P_Out;
};
void creeFile (struct file *f) ;
int file_vide ( struct file *f );
void enfiler (  int x ,  struct file * f ) ;
void defiler (  struct file *f) ;
int  premier (  struct file *f ) ;


